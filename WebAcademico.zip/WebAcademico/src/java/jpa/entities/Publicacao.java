/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jpa.entities;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author julcileabolandini
 */
@Entity
@Table(name = "PUBLICACAO")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Publicacao.findAll", query = "SELECT p FROM Publicacao p"),
    @NamedQuery(name = "Publicacao.findByIdpublicacao", query = "SELECT p FROM Publicacao p WHERE p.idpublicacao = :idpublicacao"),
    @NamedQuery(name = "Publicacao.findByTitulo", query = "SELECT p FROM Publicacao p WHERE p.titulo = :titulo"),
    @NamedQuery(name = "Publicacao.findByTipo", query = "SELECT p FROM Publicacao p WHERE p.tipo = :tipo"),
    @NamedQuery(name = "Publicacao.findByDatapublicacao", query = "SELECT p FROM Publicacao p WHERE p.datapublicacao = :datapublicacao")})
public class Publicacao implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "IDPUBLICACAO")
    private Integer idpublicacao;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "TITULO")
    private String titulo;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "TIPO")
    private String tipo;
    @Column(name = "DATAPUBLICACAO")
    @Temporal(TemporalType.DATE)
    private Date datapublicacao;
    @ManyToMany(mappedBy = "publicacaoCollection")
    private Collection<Aluno> alunoCollection;
    @JoinColumn(name = "IDORIENTADOR", referencedColumnName = "IDORIENTADOR")
    @ManyToOne
    private Orientador idorientador;

    public Publicacao() {
    }

    public Publicacao(Integer idpublicacao) {
        this.idpublicacao = idpublicacao;
    }

    public Publicacao(Integer idpublicacao, String titulo, String tipo) {
        this.idpublicacao = idpublicacao;
        this.titulo = titulo;
        this.tipo = tipo;
    }

    public Integer getIdpublicacao() {
        return idpublicacao;
    }

    public void setIdpublicacao(Integer idpublicacao) {
        this.idpublicacao = idpublicacao;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Date getDatapublicacao() {
        return datapublicacao;
    }

    public void setDatapublicacao(Date datapublicacao) {
        this.datapublicacao = datapublicacao;
    }

    @XmlTransient
    public Collection<Aluno> getAlunoCollection() {
        return alunoCollection;
    }

    public void setAlunoCollection(Collection<Aluno> alunoCollection) {
        this.alunoCollection = alunoCollection;
    }

    public Orientador getIdorientador() {
        return idorientador;
    }

    public void setIdorientador(Orientador idorientador) {
        this.idorientador = idorientador;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idpublicacao != null ? idpublicacao.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Publicacao)) {
            return false;
        }
        Publicacao other = (Publicacao) object;
        if ((this.idpublicacao == null && other.idpublicacao != null) || (this.idpublicacao != null && !this.idpublicacao.equals(other.idpublicacao))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "jpa.entities.Publicacao[ idpublicacao=" + idpublicacao + " ]";
    }
    
}
