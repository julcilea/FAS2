/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jpa.entities;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author julcileabolandini
 */
@Entity
@Table(name = "ORIENTADOR")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Orientador.findAll", query = "SELECT o FROM Orientador o"),
    @NamedQuery(name = "Orientador.findByIdorientador", query = "SELECT o FROM Orientador o WHERE o.idorientador = :idorientador"),
    @NamedQuery(name = "Orientador.findByNome", query = "SELECT o FROM Orientador o WHERE o.nome = :nome"),
    @NamedQuery(name = "Orientador.findByCpf", query = "SELECT o FROM Orientador o WHERE o.cpf = :cpf"),
    @NamedQuery(name = "Orientador.findByInstituicao", query = "SELECT o FROM Orientador o WHERE o.instituicao = :instituicao"),
    @NamedQuery(name = "Orientador.findByTitulacao", query = "SELECT o FROM Orientador o WHERE o.titulacao = :titulacao")})
public class Orientador implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "IDORIENTADOR")
    private Integer idorientador;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "NOME")
    private String nome;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "CPF")
    private String cpf;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 120)
    @Column(name = "INSTITUICAO")
    private String instituicao;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "TITULACAO")
    private String titulacao;
    @OneToMany(mappedBy = "idorientador")
    private Collection<Publicacao> publicacaoCollection;
    @OneToMany(mappedBy = "idorientador")
    private Collection<Aluno> alunoCollection;

    public Orientador() {
    }

    public Orientador(Integer idorientador) {
        this.idorientador = idorientador;
    }

    public Orientador(Integer idorientador, String nome, String cpf, String instituicao, String titulacao) {
        this.idorientador = idorientador;
        this.nome = nome;
        this.cpf = cpf;
        this.instituicao = instituicao;
        this.titulacao = titulacao;
    }

    public Integer getIdorientador() {
        return idorientador;
    }

    public void setIdorientador(Integer idorientador) {
        this.idorientador = idorientador;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getInstituicao() {
        return instituicao;
    }

    public void setInstituicao(String instituicao) {
        this.instituicao = instituicao;
    }

    public String getTitulacao() {
        return titulacao;
    }

    public void setTitulacao(String titulacao) {
        this.titulacao = titulacao;
    }

    @XmlTransient
    public Collection<Publicacao> getPublicacaoCollection() {
        return publicacaoCollection;
    }

    public void setPublicacaoCollection(Collection<Publicacao> publicacaoCollection) {
        this.publicacaoCollection = publicacaoCollection;
    }

    @XmlTransient
    public Collection<Aluno> getAlunoCollection() {
        return alunoCollection;
    }

    public void setAlunoCollection(Collection<Aluno> alunoCollection) {
        this.alunoCollection = alunoCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idorientador != null ? idorientador.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Orientador)) {
            return false;
        }
        Orientador other = (Orientador) object;
        if ((this.idorientador == null && other.idorientador != null) || (this.idorientador != null && !this.idorientador.equals(other.idorientador))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "jpa.entities.Orientador[ idorientador=" + idorientador + " ]";
    }
    
}
